#include "std_types.h"
#include "GPIO_interface.h"


#define INPUT_ANALOG							(u8)0
#define INPUT_FLOATING						(u8)4
#define INPUT_PULL_UP_DWON				(u8)8

#define PORTA_BASE_ADDRESS 0x40010800


#define PORTB_BASE_ADDRESS 0x40010C00

#define PORTC_BASE_ADDRESS 0x40011000



typedef struct
{
	u32 CRL;
	u32 CRH;
	u32 IDR;
	u32 ODR;
	u32 BSR;
	u32 BRR;
	u32 LCK;
}GPIOstruct;

static volatile GPIOstruct* GPIOA = (const volatile GPIOstruct*) PORTA_BASE_ADDRESS;
static volatile GPIOstruct* GPIOB = (const volatile GPIOstruct*) PORTB_BASE_ADDRESS;
static volatile GPIOstruct* GPIOC = (const volatile GPIOstruct*) PORTC_BASE_ADDRESS;

typedef struct{
	u32 pin;
	u8 speed;
	u8 mode;
	u8 port;
}GPIO_t;



void GPIO_initPin(GPIO_t* hal)
{
	switch(hal->port)
	{
		case PORTA:
		switch (pin)
		break;
		
		case PORTB:
		break;
		
		case PORTC:
		break;
	}
}

void GPIO_writePin(GPIO_t* hal, u8 state)
{
		switch(hal->port)
	{
		case PORTA:
			if(state == GPIO_SET)
			{	
				GPIOA->BSR = hal->pin;
			}
			else if(state == GPIO_RESET)
			{	
				GPIOA->BRR = hal->pin;
			}
		break;
		
		case PORTB:
			if(state == GPIO_SET)
			{	
				GPIOB->BSR = hal->pin;
			}
			else if(state == GPIO_RESET)
			{	
				GPIOB->BRR = hal->pin;
			}
		break;
		
		case PORTC:
			if(state == GPIO_SET)
			{	
				GPIOC->BSR = hal->pin;
			}
			else if(state == GPIO_RESET)
			{	
				GPIOC->BRR = hal->pin;
			}
		break;
	}
}

u8 GPIO_readPin(GPIO_t* hal)
{
	u8 status=0;
		switch(hal->port)
	{
		case PORTA:
			
			if(GPIOA->IDR & hal->pin)
			{
				status=1;
			}
			
		break;
		
		case PORTB:
		
			if(GPIOB->IDR & hal->pin)
			{
				status=1;
			}
		
		break;
		
		case PORTC:
		
			if(GPIOC->IDR & hal->pin)
			{
				status=1;
			}
		
		break;
	}
	return status;
}
