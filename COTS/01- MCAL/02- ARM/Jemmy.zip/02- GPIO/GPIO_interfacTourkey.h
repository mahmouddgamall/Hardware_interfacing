
#define MODE_INPUT_ANALOG							(u8)0
#define MODE_INPUT_FLOATING						(u8)1
#define MODE_INPUT_PULL_UP_DOWN				(u8)2
#define MODE_OUTPUT_PUSH_PULL				(u8)0
#define MODE_OUTPUT_OPEN_DRAIN					(u8)1
#define MODE_OUTPUT_AF_PUSH_PULL		(u8)2
#define MODE_OUTPUT_AF_OPEN_DRAIN		(u8)3


#define	SPEED_10_MHZ							(u8)0
#define	SPEED_2_MHZ								(u8)1
#define	SPEED_50_MHZ							(u8)2


#define PORTA 										(u8)0
#define PORTB 										(u8)1
#define PORTC 										(u8)2


#define	GPIO_RESET									(u8)0
#define	GPIO_SET									(u8)1

#define	PIN_0											(u8)1
#define	PIN_1											(u8)2
#define	PIN_2											(u8)4
#define	PIN_3											(u8)8
#define	PIN_4											(u8)0x10
#define	PIN_5											(u8)0x20
#define	PIN_6											(u8)0x40
#define	PIN_7											(u8)0x80
#define	PIN_8											(u32)0x100
#define	PIN_9											(u32)0x200
#define	PIN_10										(u32)0x400
#define	PIN_11										(u32)0x800
#define	PIN_12										(u32)0x1000
#define	PIN_13										(u32)0x2000
#define	PIN_14										(u32)0x4000
#define	PIN_15										(u32)0x8000


void GPIO_initPin(GPIO_t* hal);

void GPIO_writePin(GPIO_t* hal, u8 state);

u8 GPIO_readPin(GPIO_t* hal);


