void sevensegSetNum (u8 num);

void sevensegEnable (u8 sevensegNum);

void sevensegDisable (u8 sevensegNum);
