extern u8 keypadGetPressedKey (void);
