void DCMOTOR_voidRotateMotorRight(void);

void DCMOTOR_voidRotateMotorLeft(void);

void DCMOTOR_voidStop(void);
