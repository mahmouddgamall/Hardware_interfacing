/*	Choose a value from 0 to 7	*/

#define	DCMOTOR_LEFTLEG_PIN				1
#define	DCMOTOR_RIGHTLEG_PIN			0

/*	Choose from 'A', 'B', 'C', 'D'*/

#define	DCMOTOR_Port		'A'

/*	Choose 0 or 1	*/

