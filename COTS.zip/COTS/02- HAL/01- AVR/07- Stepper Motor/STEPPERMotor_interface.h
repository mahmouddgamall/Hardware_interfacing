void STEPPERMOTOR_voidRotateMotorRight(u8 In_u8STep);

void STEPPERMOTOR_voidRotateMotorLeft(u8 In_u8STep);

void STEPPERMOTOR_voidStop(void);
