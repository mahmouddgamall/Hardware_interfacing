/*	Choose a value from 0 to 7	*/

#define	STEPPER_MOTOR_PIN_A				0
#define	STEPPER_MOTOR_PIN_B				1
#define	STEPPER_MOTOR_PIN_C				2
#define	STEPPER_MOTOR_PIN_D				3

/*	Choose from 'A', 'B', 'C', 'D'*/

#define	STEPPER_MOTOR_Port		'A'

/*	Choose 0 or 1	*/

