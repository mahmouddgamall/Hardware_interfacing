/*	Choose a value from 0 to 7	*/

#define	LED_Pin	1

/*	Choose from 'A', 'B', 'C', 'D'*/

#define	LED_Port		'A'

/*	Choose 0 or 1	*/

#define LED_Mode	1
