u8 getSwitchValue(void);

