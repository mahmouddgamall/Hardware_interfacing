/*	Choose a value from 0 to 7	*/

#define	SWITCH_Pin	0

/*	Choose from 'A', 'B', 'C', 'D'*/

#define	SWITCH_Port		'A'

/*	Choose pull down 0 or pull up 1	*/

#define RELEASE_State	1	