#define		LEDMATRIX_ORANGE		1
#define		LEDMATRIX_RED			2
#define		LEDMATRIX_YELLOW		3



extern void LEDMATRIX_voidWriteChar (u8 * Copy_u8Data, u8 Copy_u8Color);
