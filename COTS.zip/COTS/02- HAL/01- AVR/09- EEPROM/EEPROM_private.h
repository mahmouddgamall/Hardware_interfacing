/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef EEPROM_PRIVATE_H
#define EEPROM_PRIVATE_H

#define EEPROM_FIXED_ADDRESS		0x5
// #define	

#endif