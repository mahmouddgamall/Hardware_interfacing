/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef NOKIA5110_PRIVATE_H
#define NOKIA5110_PRIVATE_H





#endif