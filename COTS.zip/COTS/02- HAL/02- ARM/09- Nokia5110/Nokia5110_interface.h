/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef NOKIA5110_INTERFACE_H
#define NOKIA5110_INTERFACE_H

#endif