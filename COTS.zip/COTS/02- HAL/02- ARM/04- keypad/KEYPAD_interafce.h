void KEYPAD_Init(void);
u8 KEYPAD_GetPressedKey(void);
