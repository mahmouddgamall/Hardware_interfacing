#ifndef MOTOR_ENCODER_INTERFACE_H
#define MOTOR_ENCODER_INTERFACE_H

u8 Encoder_u8Pass(void);

#endif