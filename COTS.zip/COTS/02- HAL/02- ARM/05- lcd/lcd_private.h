#ifndef LCD_PRIVATE_H
#define LCD_PRIVATE_H

static void CLCD_voidSetDataPort(u8 Copy_u8Data);

static void CLCD_voidSetHalfDataPort(u8 Copy_u8Data);

#deine FOUR_BITS_MODE			0
#define	EIGHT_BITS_MODE		1

#endif