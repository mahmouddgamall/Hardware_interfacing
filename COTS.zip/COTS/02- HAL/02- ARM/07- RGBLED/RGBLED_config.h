
/*	Choose from 'A', 'B', 'C'*/

#define	FIRST_LEDS_Port		'A'
#define	SECOND_LEDS_Port		'B'

/*	Choose 0 or 1	*/

#define LED_Mode	1
