u8 getSwitchValue(u8 mySwitch);

