#ifndef UARTM_CONFIG_H
#define UARTM_CONFIG_H

#define UARTM_u8_MAX_QUEUE_SIZE		10

#endif