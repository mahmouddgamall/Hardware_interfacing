/***************************************************
Author	: Mahmoud Gamal
Date		: 10 March 2020
Version	: V01

***************************************************/

#ifndef DMA_CONFIG_H
#define DMA_CONFIG_H

#endif