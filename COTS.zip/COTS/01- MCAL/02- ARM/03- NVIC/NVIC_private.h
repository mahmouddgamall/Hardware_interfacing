#ifndef NVIC_PRIVATE_H
#define NVIC_PRIVATE_H

#endif