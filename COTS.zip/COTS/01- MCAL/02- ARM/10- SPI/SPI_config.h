/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef SPI_CONFIG_H
#define SPI_CONFIG_H

#endif