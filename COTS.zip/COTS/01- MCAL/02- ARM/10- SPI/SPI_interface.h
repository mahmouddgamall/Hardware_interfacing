/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef SPI_INTERFACE_H
#define SPI_INTERFACE_H

#endif