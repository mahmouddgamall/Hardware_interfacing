/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#include "std_types.h"
#include "bit_math.h"
#include "SPI_config.h"
#include "SPI_private.h"
#include "SPI_register.h"
#include "SPI_interface.h"
