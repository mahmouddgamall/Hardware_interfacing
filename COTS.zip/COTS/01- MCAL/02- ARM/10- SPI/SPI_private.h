/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef SPI_PRIVATE_H
#define SPI_PRIVATE_H



#endif