#ifndef ADC_PRIVATE_H
#define ADC_PRIVATE_H



void __vector_16(void) __attribute__((signal,used));

#endif
