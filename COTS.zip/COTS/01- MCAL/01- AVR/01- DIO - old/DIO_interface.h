void setPinDirection(u8 port, u8 pin, u8 direction);
void setPinValue(u8 port, u8 pin, u8 direction);
u8 getPinValue(u8 port, u8 pin);
