void portInit(void);

void setPinValue(u8 port, u8 pin, u8 value);

u8 getPinValue(u8 port, u8 pin);

void setPort(u8 port);

void clearPort(u8 port);