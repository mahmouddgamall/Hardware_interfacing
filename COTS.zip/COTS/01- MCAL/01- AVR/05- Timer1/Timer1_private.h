/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef TIMER1_PRIVATE_H
#define TIMER1_PRIVATE_H



#define	TCCR1_MODE_MASK			0b1111110011100111
#define TIMER1_INTERRUPT_MASK	0b11111100
#define	TIMER1_OC0_MASK			0x0FFF

#endif
