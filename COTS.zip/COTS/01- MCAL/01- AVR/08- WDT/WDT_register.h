/**************************************************** 
 	 Author: Mahmoud Gamal
************************************************/
#ifndef WDT_REGISTER_H
#define WDT_REGISTER_H

#define WDTCR		*((u8*)0x41)

#endif